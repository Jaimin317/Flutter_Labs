# lab7_icon

A new Flutter project.

![image](https://user-images.githubusercontent.com/81226571/189967232-0bc06e26-f712-4849-8872-3e906f34bb5b.png)
