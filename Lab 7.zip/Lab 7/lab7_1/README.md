# lab7

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

![image](https://user-images.githubusercontent.com/81226571/189966829-e479440a-396d-46de-b8ab-da510a8abb3a.png)
